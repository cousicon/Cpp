/* A 'string set' is defined as a set of strings stored
 * in sorted order in a drop list.  See the class video
 * for details.
 *
 * For lists that do not exceed 2 ^ (max_width + 1)
 * elements, the add, remove, and contains functions are 
 * O(lg size) on average.  The operator= and get_elements 
 * functions are O(size).   
 * 
 * Peter Jensen
 * September 18, 2020
 * Connor Cousineau	
 * Oct 1 2020
 */

#include "string_set.h"
#include <iostream>  // For debugging, if needed.
#include<time.h>
#include<stdlib.h>
namespace cs3505
{
  /*******************************************************
   * string_set member function definitions
   ***************************************************** */
  
  /** Constructor:  The parameter indicates the maximum
    * width of the next pointers in the drop list nodes.
    */
  string_set::string_set(int max_width)
  {
    this->max_width = max_width;
    head = new node(max_width);
    srand(time(NULL));
    size = 0;
  }

  
  /** Copy constructor:  Initialize this set
    * to contain exactly the same elements as
    * another set.
    */
  string_set::string_set (const string_set & other)
  {
    *this = other;
  }


  /** Destructor:  Release any memory allocated
    * for this object.
    */
  string_set::~string_set()
  {
    node* current = head;
    node* temp = head;
    while(current != NULL)
    {
      	temp = current->pointers[0];
	delete current;
	current = temp;
    }
 
  }
  /** Add: adds items to the list.
    * Given a std:string, it will be added to the drop list.
    */
  void string_set::add(const std::string &target)
  {
    //needs cotains first
    if(contains(target))
      return;
   std::vector<node*> prior;
   for(int i = 0; i < max_width; i++) //fills vector with NULL
     {
       prior.push_back(NULL);
     }
    node* current = head; //points to the start of the list.
    for(int i = max_width-1; i>=0; i--) 
      {
	while(current->pointers[i] != NULL && current->pointers[i]->data.compare(target) < 0)
	  {
	      current = current->pointers[i];//moves the list ahead.
	  }
	prior[i] = current;//adds the correct pointer to the list.
      }
    node *temp = new node(target, max_width); //creates a new node to add to the list.

    for(int i = temp->pointers.size()-1; i >= 0; i--) //change appropriate pointers.
      {
	temp->pointers[i] = prior[i]->pointers[i];
	prior[i]->pointers[i] = temp;
      }
    size++;
  }

  /**
    *   This function will remove the requests target
    *	    params: one input string
    */
  void string_set::remove(const std::string &target)
  {
    //needs cotains first
    if(!contains(target))
      return;
   std::vector<node*> prior;
   for(int i = 0; i < max_width; i++)
     {
       prior.push_back(NULL);//fills with NULL
     }
    node* current = head;
    for(int i = max_width-1; i>=0; i--)
      {
	while(current->pointers[i] != NULL && current->pointers[i]->data.compare(target) < 0)
	  {
	      current = current->pointers[i]; // moves the list ahead
	  }
	prior[i] = current;//adds to the temp pointer list.
      }
    current = current->pointers[0];
    for(int i = current->pointers.size()-1; i >= 0; i--)
      {
	prior[i]->pointers[i] = current->pointers[i]; // moves pointers ahead of the "removed" node
      }
    delete current;//collect the trash.
    size--;
  }
  /**Contains: determins whether a std:string is in the list.
    * Given a std::string, it will return a bool.
    * true if yes, false if no.
    */
  bool string_set::contains(const std::string &target) const
  {
        if(size == 0) // if nothing in the list, return.
      return false;
	node* current = head;
    for(int i = max_width-1; i>=0; i--)
      {
	while(current->pointers[i]!= NULL && current->pointers[i]->data.compare(target) <= 0)
	  {
	    if(current->data == target || current->pointers[i]->data == target)//if this node or next is the target return true.
	      return true;
	    current = current->pointers[i];//moves list forwards.
	  }
      }
    return false; // not in the list.
  }
  //return the size parameter of the list.
  int string_set::get_size () const
  {
    return size;
  }
  /**operator=: Will overwrite the right hand side to contain only the left hand side.
    * Given a string_set. change the lhs to be equal to the rhs.
    */
  string_set & string_set::operator=(const string_set & rhs)
  {
	// make sure its empty
	//copy all the elements into it
    node* current = head;
    node* temp = head;
    while(current != NULL)
      {
	temp = current->pointers[0];//save data
	delete current;//delete node
	current = temp;//move ahead
      }
    size = 0;//set size to reflect delete
    this->max_width = rhs.max_width;
    head = new node(max_width); //create a new node.
    node*prior = rhs.head->pointers[0];	
    while(prior != NULL)
      {
	add(prior->data); //add to the list
	prior = prior->pointers[0]; //move ahead
      }  
  }
  /**get_elements: will return a std::vector containing all of this sets elements.
    *  Must be a std::vector<std::string> to work.
    */
  std::vector<std::string> string_set::get_elements()
  {
    std::vector<std::string> elements;
    node*prior = head->pointers[0];
    while(prior != NULL)
    {
     elements.push_back(prior->data); //add all the data
     prior = prior->pointers[0];
    }
    return elements;
  }
}
