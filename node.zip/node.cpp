/* This node class is used to build linked lists for the
 * string_set class.
 *
 * Peter Jensen
 * September 18, 2020
 * Connor Cousineau	
 * Oct 1 2020	
 */

#include "node.h"
#include<time.h>
#include<string>
#include<vector>
#include<stdlib.h>
#include<iostream>
// By default, functions are not in a namespace.  They are not in any
// class.  Symbols defined here are globally available.  We need to
// qualify our function names so that you are definining our 
// cs3505::node class functions.
//
// Note that you can also use the namespace cs3505 { } block, this 
// would eliminate one level of name qualification.  The 
// 'using' statement will not help in this situation.  
// 
// Qualify it as shown here for functions: 
//      cs3505::node::functionname, etc.

/*******************************************************
 * node member function definitions
 ***************************************************** */

// Students will decide how to implement the constructor, 
// destructor, and any helper methods.
namespace cs3505
{
  
  node::node(int width)// this one must be called first or everything will go wrong!
  {
    data = "";
    for(int i = 0; i < width; i++)
     {
       pointers.push_back(NULL);
     }	
  }

  node::node(const std::string &s, int width )//assumes a header node exists 
  {
    data = s;
   int this_width = 1;
   int coin = rand() % 2+1;//between 1 and the max number
   while(coin%2 != 0)//flips a coin to determine size.
   { 
     coin = rand() % 2+1;
     this_width++;
   }
   for(int i = 0; i < this_width; i++)
     {
       pointers.push_back(NULL); //add NULL for new width.
     }
  }
  node::~node()
  {
  } // not needed
  
}
