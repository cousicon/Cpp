#include<iostream>
#include<fstream>
#include <string>
#include <sstream>
#include <jsoncpp/json/value.h>
#include <jsoncpp/json/reader.h>
using namespace std;

extern "C" 
{
#include<libavcodec/avcodec.h>
#include<libavutil/imgutils.h>
#include<libswscale/swscale.h>
#include<libavformat/avformat.h>
#include<libavfilter/avfilter.h>
#include<libavfilter/buffersink.h>
#include<libavfilter/buffersrc.h>
};

AVFrame * open_file (const char * filename)
{
    AVFormatContext *format_ctx = NULL;
    int error_code;
    AVCodec *dec = NULL;
    
    error_code = avformat_open_input(&format_ctx, filename, NULL, NULL);
    if (error_code != 0)
    {
        cout << "Could not open file " << filename << endl;
        return NULL;
    }
    
    error_code = avformat_find_stream_info(format_ctx, NULL);
    if (error_code != 0)
    {
        cout << "Could not find stream info for " << filename << endl;
        return NULL;
    }
    
    AVCodec *codec = NULL;
    dec = avcodec_find_decoder(format_ctx->streams[0]->codec->codec_id);
    if (!dec)
    {
        cout << "Could not find codec for " << filename << endl;
        return NULL;
    }
    
    AVCodecContext * codec_ctx = format_ctx->streams[0]->codec;
    
    error_code = avcodec_open2(codec_ctx, dec, NULL);
    if (error_code != 0)
    {
        cout << "Could not open codec for " << filename << endl;
        return NULL;
    }
    
    AVFrame *frame;
    AVPacket packet;
    
    frame = av_frame_alloc();
    
    av_read_frame(format_ctx, &packet);
    
    int done;
    avcodec_decode_video2(codec_ctx, frame, &done, &packet);
    
    // Convet to RGB
    AVFrame *rgbFrame = av_frame_alloc();
    rgbFrame->width = frame->width;
    rgbFrame->height = frame->height;
    rgbFrame->format = AV_PIX_FMT_BGR24;
    int numBytes = avpicture_get_size(AV_PIX_FMT_BGR24, codec_ctx->width, codec_ctx->height);
    uint8_t *buffer = (uint8_t *) av_malloc(numBytes);
    avpicture_fill((AVPicture*)rgbFrame, buffer, AV_PIX_FMT_BGR24, codec_ctx->width, codec_ctx->height);
    struct SwsContext *sws_ctx;
    sws_ctx = sws_getContext(frame->width, frame->height, (AVPixelFormat) frame->format, frame->width, frame->height, AV_PIX_FMT_RGB24, SWS_BILINEAR, NULL, NULL, NULL);
    sws_scale(sws_ctx, frame->data, frame->linesize, 0, codec_ctx->height, rgbFrame->data, rgbFrame->linesize);
    
    return rgbFrame;
}

AVPacket * encode (AVFrame *frame)
{
    AVCodec * out_codec = avcodec_find_encoder(AV_CODEC_ID_BMP);
    if (out_codec == NULL)
    {
        cout << "Failed to find encoder" << endl;
        return NULL;
    }
    
    AVCodecContext * out_ctx = avcodec_alloc_context3(out_codec);
    if (out_ctx == NULL)
    {
        cout << "Failed to create context" << endl;
        return NULL;
    }
    
    out_ctx->pix_fmt =AV_PIX_FMT_BGR24;
    out_ctx->width = frame->width;
    out_ctx->height = frame->height;
    out_ctx->time_base.num = 1;
    out_ctx->time_base.den = 1;
    
    avcodec_open2(out_ctx, out_codec, NULL);
    
    AVPacket * packet;
    av_init_packet(packet);
    packet->data = NULL;
    packet->size = 0;
    
    int done;
    int size;
    size = avcodec_encode_video2(out_ctx, packet, frame, &done);
    if (size < 0)
    {
        cout << "Encode error" << endl;
        return NULL;
    }
    
    cout << "Encoded" << endl;
    
    return packet;
}
    
int write_image(const char * filename, AVPacket * packet)
{
    ofstream out_file(std::string(filename) + ".bmp");
    out_file.write((const char *)packet->data, packet->size);
    out_file.close();
    return 0;
}

AVFrame * filter_frame(const char * filters_descr, AVFrame * frame)
{
    AVFilterContext *buffersink_ctx;
    AVFilterContext *buffersrc_ctx;
    AVFilterGraph *filter_graph;
    
    char args[512];
    int ret;
    const AVFilter *buffersrc  = avfilter_get_by_name("buffer");
    const AVFilter *buffersink = avfilter_get_by_name("buffersink");
    AVFilterInOut *outputs = avfilter_inout_alloc();
    AVFilterInOut *inputs  = avfilter_inout_alloc();
    enum AVPixelFormat pix_fmts[] = { AV_PIX_FMT_BGR24, AV_PIX_FMT_NONE };
    filter_graph = avfilter_graph_alloc();
    
    /* buffer video source: the decoded frames from the decoder will be inserted here. */
    snprintf(args, sizeof(args), "%d:%d:%d:%d:%d:%d:%d",
            frame->width, frame->height, frame->format,
            1, 1,
            frame->sample_aspect_ratio.num, frame->sample_aspect_ratio.den);
    ret = avfilter_graph_create_filter(&buffersrc_ctx, buffersrc, "in",
                                        args, NULL, filter_graph);
    if (ret < 0) {
        av_log(NULL, AV_LOG_ERROR, "Cannot create buffer source\n");
        return NULL;
    }
    
    /* buffer video sink: to terminate the filter chain. */
    ret = avfilter_graph_create_filter(&buffersink_ctx, buffersink, "out",
                                        NULL, pix_fmts, filter_graph);
    if (ret < 0) {
        av_log(NULL, AV_LOG_ERROR, "Cannot create buffer sink\n");
        return NULL;
    }
    
    /* Endpoints for the filter graph. */
    outputs->name       = av_strdup("in");
    outputs->filter_ctx = buffersrc_ctx;
    outputs->pad_idx    = 0;
    outputs->next       = NULL;
    
    inputs->name       = av_strdup("out");
    inputs->filter_ctx = buffersink_ctx;
    inputs->pad_idx    = 0;
    inputs->next       = NULL;
    
    if ((ret = avfilter_graph_parse(filter_graph, filters_descr,
                                    inputs, outputs, NULL)) < 0)
        return NULL;
    
    if ((ret = avfilter_graph_config(filter_graph, NULL)) < 0)
        return NULL;
        
        
    AVFrame *picref;
    picref = av_frame_alloc();
    /* push the decoded frame into the filtergraph */
    av_buffersrc_add_frame(buffersrc_ctx, frame);
    av_buffersink_get_frame(buffersink_ctx, picref);
    
    return picref;
 } 
 
// void sort_data(const char * folder)
// {
//     Json::Value root;
//     std::ifstream ifs;
//     ifs.open("air_data.txt");
//     Json::CharReaderBuilder builder;
//     builder["collectComments"] = true;
//     JSONCPP_STRING errs;
//     if (!parseFromStream(builder, ifs, &root, &errs)) {
//         cout << errs << endl;
//     }
    
//     //cout << data << endl;
    
//     // for (auto& [key, val] : data.items())
//     // {
//     //     std::cout << "key: " << key << ", value:" << val << '\n';
//     // }
// }
 
int main()
{
    int video_time = 1;
    
    tuple<string, string> t1 = make_tuple("2020-12-10T11:00:00", "Current Ozone levels are 0.008,\n8 Hour Ozone average is 0.003,\nCurrent PM 2.5 levels are 41");
    tuple<string, string> t2 = make_tuple("2020-12-10T11:11:00", "Current Ozone levels are 0.009,\n8 Hour Ozone average is 0.003,\nCurrent PM 2.5 levels are 41");
    tuple<string, string> t3 = make_tuple("2020-12-10T11:30:00", "Current Ozone levels are 0.018,\n8 Hour Ozone average is 0.003,\nCurrent PM 2.5 levels are 41");
    tuple<string, string> data [] = {t1, t2, t3};
    
    int y,M,d,h,m;
    float s;
    
    stringstream st0;
    st0 << get<0>(data[(sizeof(data)/sizeof(*data))-1]);
    sscanf(st0.str().c_str(), "%d-%d-%dT%d:%d:%fZ", &y, &M, &d, &h, &m, &s);
    
    int y1,M1,d1,h1,m1;
    float s1;
    stringstream st1;
    st1 << get<0>(data[0]);
    sscanf(st1.str().c_str(), "%d-%d-%dT%d:%d:%fZ", &y1, &M1, &d1, &h1, &m1, &s1);
    
    int total_sec = (M-M1)*2592000 + (d-d1)*86400 + (h-h1)*3600 + (m-m1)*60 + (s-s1);
    
    int points [(sizeof(data)/sizeof(*data))];
    
    int time_len = (video_time*30)*500;
    
    for (int i = 0; i < (sizeof(data)/sizeof(*data))-1; i++)
    {
        stringstream st2;
        st2.str("");
        st2 << get<0>(data[i+1]);
        sscanf(st2.str().c_str(), "%d-%d-%dT%d:%d:%fZ", &y, &M, &d, &h, &m, &s);

        stringstream st3;
        st3.str("");
        st3 << get<0>(data[i]);
        sscanf(st3.str().c_str(), "%d-%d-%dT%d:%d:%fZ", &y1, &M1, &d1, &h1, &m1, &s1);
        
        int sec = (M-M1)*2592000 + (d-d1)*86400 + (h-h1)*3600 + (m-m1)*60 + (s-s1);
        
        points[i] = (time_len)*(sec/total_sec);
    }
    
    
    
    int num_frames = video_time*30;
    
    for (int i = 0; i < num_frames; i++)
    {
        AVFrame *frame;
        frame = open_file("./bg.png");
        stringstream s;
        s << "scale=500:500,"; //drawtext=text='|':x=10:y=250";
        for (int j = 0; j < sizeof(data)/sizeof(*data); j++)
        {
            if (points[j] >= 0 && points[j] <= 500) {
                s << "drawtext=text='|\n" << get<1>(data[j]) << "':x=" << points[j] << ":y=250,";
                points[j] = points[j] - 1;
            }
        }
        string f0 = s.str();
        if (f0.length() > 0)
        {
            f0 = f0.substr(0, f0.size()-1);
            const char * f1 = f0.c_str();
            frame = filter_frame(f1, frame);
            AVPacket * p = encode(frame);
            string i_string = "./frames/" + to_string(i);
            const char *i_char = i_string.c_str();
            write_image(i_char, p);
        }
    }
    
    // PLEASE LEAVE THIS SECTION COMMENTED OUT
    // int pixels = (frame -> width ) * (frame -> height) * 3 -1;
    // for(int i = 0 ; i < pixels; i +=3)
    // {
    //     int temp = frame ->data[0][i];
    //     frame ->data[0][i] =  frame ->data[0][i+2];
    //     frame -> data[0][i+2] =temp;
         
    // } // change the color back
    return 0;
}
