import json
import requests
import datetime


def get():
    user = "KUTV2News"

    headers = {
        'Authorization': 'Bearer AAAAAAAAAAAAAAAAAAAAABt7JgEAAAAAddTNneOsr5Nm7ee2y2L2j%2Fh0yps%3DLJ1qVWKeAPVrBg12yCDJ28NTYznRe2KwndHOxfeZjGUy7khc63',
        'Cookie': 'personalization_id="v1_nPo89maPqwF6A3koZJyb2w=="; guest_id=v1%3A160513101730462972'
    }
    time = (datetime.datetime.now() - datetime.timedelta(minutes=60)).isoformat()
    url = 'https://api.twitter.com/2/tweets/search/recent?query=from:' + str(user) + '&start_time=' + str(
        time) + 'Z&tweet.fields=created_at'
    r = requests.request("GET", url, headers=headers).json()

    num_tweets = r["meta"]["result_count"];

    i = 0
    while i < num_tweets:
        time = r['data'][i]['created_at']
        time = datetime.datetime.strptime(time, '%Y-%m-%dT%H:%M:%S.%fZ')
        filename_time = time.strftime('Y%YM%mD%dH%HM%MS%S')
        ian_data_time = time.strftime('%Y-%m-%dT%H:%M:%S')
        data = {}
        data[ian_data_time] = (user + " Tweets " + r["data"][i]["text"])
        with open('tmp/twit' + filename_time + '.json', 'w') as outfile:
            json.dump(data, outfile)
        json.dumps(r["data"][i]['created_at'])
        i = i + 1


if __name__ == '__main__':
    get()
