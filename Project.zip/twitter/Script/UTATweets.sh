#!/bin/bash

account="KUTV2News"
time=$(date --utc +"%Y-%m-%dT%T.000Z" --date="60 minutes ago")
filename=$(date +"%y-%m-%d-%T")

curl --location --request GET "https://api.twitter.com/2/tweets/search/recent?query=from:$account&start_time=$time&tweet.fields=created_at" \
     --header 'Authorization: Bearer AAAAAAAAAAAAAAAAAAAAABt7JgEAAAAAddTNneOsr5Nm7ee2y2L2j%2Fh0yps%3DLJ1qVWKeAPVrBg12yCDJ28NTYznRe2KwndHOxfeZjGUy7khc63' \
     --header 'Cookie: personalization_id="v1_nPo89maPqwF6A3koZJyb2w=="; guest_id=v1%3A160513101730462972' \
     --output "/tmp/$account$filename.json"
     
python3 Script/Script/get_tweets.py

/bin/bash

