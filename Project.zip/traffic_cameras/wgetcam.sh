#!/bin/bash

#A bash script

wget http://www.udottraffic.utah.gov/1_devices/aux114.jpeg;
mv aux114.jpeg /traffic_cameras/pictures/$(date +"%m_%d_%H_%M").jpeg

cd /traffic_cameras/pictures
LIST="$(ls *.jpeg)"
DATE="$(date --date="yesterday" +"%m_%d_%H_%M").jpeg"
for file in $LIST; do
    echo $file
    echo $DATE
    if [[ "$file" < "$DATE" ]]; then
        echo $file $DATE
        rm $file
    fi
done