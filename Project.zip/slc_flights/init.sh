#!/bin/bash
python3 code/API_Call.py