import json
import requests
from datetime import date

# Create an empty json object
total_flights = {};

# Open flight_data.txt and read the contents into total_flights
with open('data/flight_data.txt') as json_file:
    try:
        data = json.load(json_file)
        for key, value in data.items():
            total_flights[key] = value
    except:
        pass

# API parameters
params = {
  'access_key': '3b2b1ad263f6b812cd1fcccf5b8d16e9',
  'limit': '100',
  'flight_status': 'landed',
  'arr_iata': 'SLC'
}

# Call the api with the parameters
api_result = requests.get('http://api.aviationstack.com/v1/flights', params)

# Put the results into a json object
api_response = api_result.json()

for flight in api_response['data']:
    # If this flight isn't already in total_flights, add it. Handle the bad data by skipping it.
    try:
        if flight['arrival']['actual'] not in total_flights:
            total_flights[flight['arrival']['actual']] = flight['airline']['name'] + " flight " + flight['flight']['number'] + " from " + flight['departure']['airport'] + " landed at SLC International"
    except:
        pass

# Write the flights back to the file
with open('data/flight_data.txt', 'w') as outfile:
    json.dump(total_flights, outfile)

