#!/usr/bin/env python3
import json
import requests
import datetime
import os
from collections import OrderedDict
from datetime import timedelta

weather_data={}
with open('weather_data.txt') as json_file:
    try:
        data = json.load(json_file)
        for key, value in data.items():
            weather_data[key] = value
    except:
        pass

callAPI = requests.get('http://api.openweathermap.org/data/2.5/weather?q=salt%20lake%20city&appid=96b325378ce087a783897b5d7465743d')


rawData = callAPI.json()
current_time= rawData['dt']
CTtimestamp = datetime.datetime.fromtimestamp(current_time)

CTtimestamp = CTtimestamp - timedelta(hours=7)


t = CTtimestamp.isoformat()


temp= rawData['weather']
output = "right now the weather is " +  temp[0]['description'] + ", \n "

temp = rawData['main']
output+= " lowest temperature is " +str( round(temp['temp_min'] - 273.15, 3)) + ", \n"
output+= "  the highest temperature is " + str(round(temp['temp_max'] - 273.15, 3)) + ", \n"
output+= "feels like " + str(round(temp['feels_like'] - 273.15, 3)) + ".\n "
output+= "Air pressure is " + str(temp['pressure']) + ". \n "
output+= "You can see things " +  str(rawData['visibility']) +"m away. \n "


sunrise_time = rawData['sys']['sunrise']
SRtimestamp = datetime.datetime.fromtimestamp(sunrise_time)
SRtimestamp = SRtimestamp - timedelta(hours=7)
dif_time = round((CTtimestamp - SRtimestamp).total_seconds()/60,2)

if(dif_time > 0):
   
    output+= "the sunrise happened " + str(dif_time) + "min ago, \n "
  
else:
    dif_time = dif_time *-1
    output+= "the sunrise will happen in " + str(dif_time) + "min \n"
    
sunset_time = rawData['sys']['sunset']
SStimestamp = datetime.datetime.fromtimestamp(sunset_time)
SStimestamp = SStimestamp - timedelta(hours=7)
dif_time = round((CTtimestamp - SStimestamp).total_seconds()/60,2)

if(dif_time > 0):
   
    output+= "the sunset happened " + str(dif_time) + "min ago, \n"
  
else:
    dif_time = dif_time *-1
    output+= "the sunset will happen in " + str(dif_time) + "min, \n"



weather_data[t] = output

weather_data = OrderedDict(sorted(weather_data.items(), reverse=True));
if(len(weather_data) > 40):
    weather_data.popitem(last=True)

    
with open ('weather_data.txt', 'w') as fp:
    json.dump(weather_data, fp)
    




