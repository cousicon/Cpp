import json
import re
from datetime import datetime
from collections import OrderedDict

total_air = {}

with open('air_data.txt', 'r') as json_file:
    try:
        data = json.load(json_file)
        for key, value in data.items():
            total_air[key] = value
            #print("Found key: ", key)

        print("Successfully opened JSON file")
    except:
        print("Unable to read air_data.txt")
        pass

    
with open ('data-air-quality.txt') as f:
    final = ""
    time = ""
    for line in f:
        reg = re.search('^<(?P<key>.*)>(?P<data>.*)<\/.*>$', line)
        key = reg.group('key')
        data = reg.group('data')

        if (key == "date"):
            # Format time to ISO8601 format
            date = datetime.strptime(data, '%m/%d/%Y %H:%M:%S')
            time = date.isoformat()

        if (data != "" and data != "-0" and key != "date"):
            title = ""
            if (key == "ozone"):
                title = "Current Ozone levels are "
            elif (key == "ozone_8hr_avg"):
                title = "8 Hour Ozone average is "
            elif (key == "pm25"):
                title = "Current PM 2.5 levels are "
            elif (key == "pm25_24hr_avg"):
                title = "24 Hour PM 2.5 average is "
            elif (key == "nox"):
                title = "Current Nitrogen Oxide levels are "
            elif (key == "no2"):
                title = "Current Nitrogen Dioxide levels are "
            elif (key == "co"):
                title = "Current Carbon Monoxide levels are "
            elif (key == "noy"):
                title = "Current NOy levels are "
            else:
                continue
                
            current = "" + title + data + ",\n"
            final += current

    if time not in total_air.keys():        
        total_air[time] = final[:len(final) - 2]

ordered = OrderedDict(sorted(total_air.items(), reverse=True));


if len(ordered) > 48:
    print("More than 48 entries, removing last.")
    ordered.popitem(last=True)


with open('air_data.txt', 'w') as outfile:
    json.dump(ordered, outfile)
