import json
import re
import os
from collections import OrderedDict

total_air = {}
file = '/home/ec2-user/efs-mount/data/air_data.txt'
with open(file, 'r') as json_file:
    try:
        data = json.load(json_file)
        for key, value in data.items():
            total_air[key] = value

    except:
        print("Unable to read " + file)
        pass

key = ""
val = ""
for entry in total_air: # gets first entry in json file (sorted)
    key = entry
    val = total_air[key]
    #print("KEY: " + key)
    #print ("Val: " + val)
    break

xpos = 50
ypos = 50
background = 'air_bg.jpg'
output_name = 'img_air'

command = 'ffmpeg -y -i ' + background + ' -vf "drawtext=text=\'' + val + '\':fontcolor=white:fontsize=25:bordercolor=black:borderw=5:x=' + str(xpos) + ':y=' + str(ypos) + ':" ' + output_name + '.jpg'
os.system(command)

video_title = "air_output.mp4"
os.system('ffmpeg -loop 1 -y -framerate 30 -i ' + output_name + '.jpg -vcodec mpeg4 -b:v 20M -t 10 ' + video_title)

#os.system('rm img_*.jpg')
