#!/bin/bash

/home/ec2-user/efs-mount/dockers
