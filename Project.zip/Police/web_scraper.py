#!/usr/bin/env python3
import json
#import beautifulsoup4
from datetime import datetime
from urllib.request import urlopen as uReq
from bs4 import BeautifulSoup as soup
my_url = 'https://dotnet.slcgov.com/Police/CADCallsForService/'
uClient = uReq(my_url)
page_html = uClient.read()
uClient.close()

page_soup = soup(page_html, "html.parser")
containers = page_soup.findAll("table",{"class":"sortable"})

case_nums = containers[0].findAll("td", {"style":"width:7%"})
call_types = containers[0].findAll("td", {"style":"width:22%"})
addresss = containers[0].findAll("td", {"style":"width:24%"})
times = containers[0].findAll("td", {"style":"width:15%"})
reports = containers[0].findAll("td", {"style":"width:5%"})

JSON_dict = {}

time_list = list(times)
address_list = list(addresss)
report_list = list(reports)

for i in range(5):
    current_string = str("Address- " + address_list[i].text.strip() + ", Report- " + report_list[i].text.strip() + ".")

    current_time = datetime.strptime(time_list[i].text.strip(), '%a %m/%d/%Y %H:%M')
    
    current_time = current_time.isoformat()
    
    JSON_dict[current_time] = current_string
    #print(current_time)
    
with open('police_data.txt','w') as outfile:
    json.dump(JSON_dict, outfile)
