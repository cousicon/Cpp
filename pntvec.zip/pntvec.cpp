/* Pntvec class
Main function: be able to add, sub, mult and intert a point vector. 
Side functions: be able to stream data in and out of said point vector.
Session date : 9/14/2020
Written by Connor Cousineau
Class: Cs3505
*/
#include<vector>
#include<iostream>
#include<fstream>
#include<sstream>
#include<string>
#include<cmath>
#include"pntvec.h"

/*
  basic constructor for no param
 */
pntvec::pntvec()
{
  x = 0.0;
  y=0.0;
  z=0.0;
}
/*
  contructor that takes in 3 doubles
 */
pntvec::pntvec(double x_value,  double y_value, double z_value)
{
  x = x_value;
  y = y_value;
  z = z_value;
}
/*
  This is the copy conrtuctor
  Takes in another pntvec
  outputs a pntvec with the values of &other
 */
pntvec::pntvec(const pntvec &other)
{
  x = other.x;
  y = other.y;
  z = other.z;
}
//returns x
double pntvec:: get_x()
{
  return x;
}
//returns y
double pntvec::get_y()
{
  return y;
}
//returns z
double pntvec::get_z()
{
  return z;
}
/*
  returns the distance of *this point to pntvec b.
  returns a double.
  *this.distance_to(b) = double value.
 */
double pntvec::distance_to(pntvec b)
{
return sqrt(pow(x-b.get_x(),2.0)+pow(y-b.get_y(),2.0)+pow(z-b.get_z(),2.0));
}
/*
  overloaded = operator
  sets the values of rhs -> *this.
 */
pntvec& pntvec::operator= (const pntvec & rhs)
{
 if(&rhs == this)
    return *this;
  this->x = rhs.x;
  this->y = rhs.y;
  this->z = rhs.z;
  return *this;
}
/*
  overloaded + operator
  allows addition of two point vectors.
  pntvec & rhs: a point vector
  outputs the addition of *This and rhs.
 */
const pntvec pntvec::operator+ (const pntvec & rhs) const
{
  pntvec vec;
  vec.x = rhs.x + this->x;
  vec.y = rhs.y + this->y;
  vec.z = rhs.z + this->z;
  return vec;
}
/*
  overloaded - operator
  allows the subtraction of two point vectors
  pntvec & rhs: a point vector
  outputs the subtraction of *this and rhs.
 */
const pntvec pntvec::operator- (const pntvec & rhs) const
{
  pntvec vec;
  vec.x = this->x - rhs.x;
  vec.y = this->y - rhs.y;
  vec.z = this->z - rhs.z;
  return vec;
}
/*
  overloaded * operator
  allows the muliplication of a pntvector and a double.
  double d: any double number.
  Scales *this by a factor of d.
 */
const pntvec pntvec::operator* (double d) const
{
  pntvec vec;
  vec.x = this->x * d;
  vec.y = this->y * d;
  vec.z = this->z * d;
  return vec;
}
/*
  overloaded negation operator.
  Will return the negetive varient of any pntvector provided.
  -(pntvec) = -pntvec;
 */
const pntvec pntvec::operator-() const
{
  pntvec vec;
  vec.x = -this->x;
  vec.y = -this->y;
  vec.z = -this->z;
  return vec;
}
//will stream any pntvec into the console out string.
std::ostream & operator<< (std::ostream & out, const pntvec & a)
{
  out << "(" << a.x << ", " << a.y << ", " << a.z << ")";
  return out;
}
//allows the steaming of three doubles into a pointvec in string stream etc
std::istream & operator>> (std::istream & in, pntvec & a)
{
  in >> a.x;
  in >> a.y;
  in >> a.z;
  return in;
}
