#ifndef PNTVEC_H
#define PNTVEC_H

#include<vector>
#include<istream>
#include<ostream>

class pntvec
{
 private:
  double x;
  double y;
  double z;
 public:
   pntvec();
   pntvec(double x,  double y, double z);
   pntvec(const pntvec &other);
   
   double get_x();
   double get_y();
   double get_z();
   double distance_to(pntvec b);

   pntvec & operator= (const pntvec & rhs);
   const pntvec operator+ (const pntvec & rhs) const;
   const pntvec operator- (const pntvec & rhs) const;
   const pntvec operator* (double d) const;
   const pntvec operator-() const;
 
   friend std::ostream & operator<< (std::ostream & out, const pntvec & a);
   friend std::istream & operator>> (std::istream & in, pntvec & a);
};

#endif
