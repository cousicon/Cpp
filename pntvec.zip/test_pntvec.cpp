/*
The purpose of this test_pntvec.cpp is to run the code found in pntvec.cpp and report 0 if all things are good
or -1 if things are not all good.
*/

#include<iostream>
#include<sstream>
#include "pntvec.h"


int main()
{
  pntvec pntvec1; //each of these pntvecs are used in the tests below
  pntvec pntvec2(1.2,1.5,1.7);
  pntvec pv3(pntvec2);
  pntvec pv4;
  pntvec pv5; //shortend for easier filling on of logic
  pntvec pv6;
  pntvec pv7;
  std::stringstream s; // for use in the << test
  s <<1.0 <<" "<<2.0 <<" " << 3.0;
  pntvec pv8;
  pntvec pv9;
  pntvec pv10;


  pv4 = pntvec2 + pv3;
  pv5 = pntvec2 - pntvec2;
  pv6 = pntvec2 * 5.0;
  pv7 = -(pntvec2);
  s >> pv8;
  pv9 = (pv8 *2.0) + -(pv8 * 10.0); // (2.0,4.0,6.0) - (10.0,20.0,30.0)  = (-8.0,-16.0,-24.0)
  pv10 = pv9 - -(pv8 *10); //(-8.0, -16.0, -24.0) - (-10.0,-20.0,-30.0) = (2.0,4.0,6.0)

  if(pv10.get_x() != 2)
    {
      std::cout << "error in complex test1"<< std::endl;
      return 255;
    }
  if(pv9.get_x() != -8.0)
    {
      std::cout << "error in complex test1"<< std::endl;
      return 255;
    }
  if(pntvec1.get_x() != 0)
    {
      std::cout << "error in empty parameter contructor"<< std::endl;
      return -1;
    }
  if(pntvec1.get_y() != 0)
    {
      std::cout << "error in empty parameter contructor"<< std::endl;
      return -1;
    }
  if(pntvec1.get_z() != 0)
    {
      std::cout << "error in empty parameter contructor"<< std::endl;
      return -1;
    }
  if(pntvec2.get_x() != 1.2)
    {
      std::cout << "error in 3 double paramerter contstructor" << std::endl;
      return -1;
    }
  if(pntvec2.get_y() != 1.5)
    {
      std::cout << "error in 3 double paramerter contstructor" << std::endl;
      return -1;
    }
  if(pntvec2.get_z() != 1.7)
    {
      std::cout << "error in 3 double paramerter contstructor" << std::endl;
      return -1;
    }
  if(pv3.get_x() != pntvec2.get_x())
    {
      std::cout << "error in copy constructor" << std::endl;
      return -1;
    }
  if(pv3.get_y() != pntvec2.get_y())
    {
      std::cout << "error in copy constructor" << std::endl;
      return -1;
    }  
  if(pv3.get_z() != pntvec2.get_z())
    {
      std::cout << "error in copy constructor" << std::endl;
      return -1;
    }
  if(pv4.get_x() != 2.4)
    {
      std::cout << "error in addition of vectors" << std::endl;
      return -1;
    }  
  if(pv4.get_y() != 3)
    {
      std::cout << "error in addition of vectors" << std::endl;
      return -1;
    }
  if(pv4.get_z() != 3.4)
    {
      std::cout << "error in addition of vectors" << std::endl;
      return -1;
    }
  if(pv5.get_x() != 0)
    {
      std::cout << "error in subtraction of vectors" << std::endl;
      return -1;
    }
  if(pv6.get_x() != 6.0)
    {
      std::cout << "error in multiplication of  vectors" << std::endl;
      return -1;
    }
  if(pv6.get_y() != 7.5)
    {
      std::cout << "error in multiplication of  vectors" << std::endl;
      return -1;
    }
  if(pv6.get_z() != 8.5)
    {
      std::cout << "error in multiplication of  vectors" << std::endl;
      return -1;
    }
  if(pv7.get_x() != -1.2)
    {
      std::cout << "error in negation of vectors"<<std::endl;
      return -1;
    }
  if(pv7.get_y() != -1.5)
    {
      std::cout << "error in negation of vectors"<<std::endl;
      return -1;
    }  
  if(pv7.get_z() != -1.7)
    {
      std::cout << "error in negation of vectors"<<std::endl;
      return -1;
    }
  if(pv8.get_x() != 1)
    {
      std::cout << "error in >> of vectors"<<std::endl;
      return -1;
    }
  if(pv8.get_y() != 2)
    {
      std::cout << "error in >> of vectors"<<std::endl;
      return -1;
    }
  if(pv8.get_z() != 3)
    {
      std::cout << "error in >> of vectors"<<std::endl;
      return -1;
    }
  if(pntvec1.distance_to(pntvec2)- 2.565151 < 1e-10)
    {
      std::cout<< "error in .distance_to()1" << std::endl;
      return -1;
    }
  if(pntvec2.distance_to(pv6) - 10.2606 < 1e-10)
    {
      std::cout << "error in .distance_to()2"<<std::endl;
      return -1;
    }
  std::cout << "No Error"<< std::endl;
  return 0;
}
