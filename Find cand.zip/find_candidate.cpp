#include<iostream>
#include<fstream>
#include<sstream>
#include<cmath>
#include<vector>
#include<string>
#include "pntvec.h"
/*
  The math needed for this assignment is as follows
  -> to compare all the data, It will be two nested loops. 
     One that cycles through the candidate data and the other to go through the field data. 
  score = the sum of all the points =pow(x,2.0)
  x = distance = sqrt(x'^2 + y'^2 + z'^2)
  x' = candadite x - p x
 */

pntvec best_coords;//this is a storage for the coords of the best score
double best_score;//this is a storage for the best score. Both will be printed at the end of the program.
std::vector<pntvec> compile_data(std::string x );//pre declares this helper function that is defined later in the program.
double compute_score(std::vector<pntvec>x,std::vector<pntvec>y);// ^
/*
this is the main/start of the program. It will call the two helper methods and eventually pring out the resulting work. 
 */
int main()
{
  best_coords.x = 0;
  best_coords.y = 0;
  best_coords.z = 0;
  best_score = 0;
  std::vector<pntvec> space_data;
  std::vector<pntvec> candidate_data;
  space_data = compile_data("point_cloud.txt");
  candidate_data = compile_data("candidates.txt");
  best_score = compute_score(space_data, candidate_data);
  
  std::cout << best_score << std::endl;
  std::cout <<best_coords.x << " ";
  std::cout << best_coords.y << " ";
  std::cout << best_coords.z << std::endl;
  return 0;
}
/*
This helper takes in the given file name and using the io stream, port all the data into the specified pntvec. 
After fetching all the data it then returns the vector.
Input: A file name in the form a std::string.
Output: a vector<pntvec> containing all the values of the provided file. 
 */
std::vector<pntvec> compile_data(std::string x )
{
  std::vector<pntvec> temp;
  pntvec p;
  std::ifstream dataFile(x.c_str()); 
 while(dataFile>>p.x>>p.y>>p.z)
    {
      if(dataFile.fail())
	break;
      temp.push_back(p);
    }
  

  return temp;

}
/*
Takes in two vectors that contain the ponit field data. 
Using the data it will compute the best cadidate.
Input: two std:vector<pntvec>.
Output: the score of the best candidate.
 */
double compute_score(std::vector<pntvec> data1, std::vector<pntvec> data2)
{
  double score;
  double best_score = 0;
  
  for(int i = 0; i < data2.size(); i++)
    {
      score = 0;
       for(int j = 0; j<data1.size(); j++)
      {
	score += pow(sqrt(pow(data2[i].x-data1[j].x,2.0) + pow(data2[i].y - data1[j].y,2.0) + pow(data2[i].z - data1[j].z,2.0)),2.0);
      }
       if(best_score == 0)
	 {
	 best_score = score;
	 best_coords.x = data2[i].x;
	 best_coords.y = data2[i].y;
	 best_coords.z = data2[i].z;
	 }

       else  if(score < best_score)
	 {
	   best_score = score;
	   best_coords.x = data2[i].x;
	   best_coords.y = data2[i].y;	   
	   best_coords.z = data2[i].z;
     	 }
    }

  return best_score;
}
